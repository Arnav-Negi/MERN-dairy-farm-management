export default function updateField(object, field, value) {
    object[field] = value
    return object
}